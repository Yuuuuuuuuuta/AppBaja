package equipepoli.com.bajapoli.ui.home;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import equipepoli.com.bajapoli.R;

public class HomeViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Bem Vindo ao App BAJA da POLI");
    }

    public LiveData<String> getText() {
        return mText;
    }
/*
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView myWebView = (WebView) findViewById(R.id.NoticiasView);
        myWebView.loadUrl("https://www.facebook.com/polibaja/");
        WebView webView = (WebView) findViewById(R.id.NoticiasView);
        myWebView.setWebViewClient(new WebViewClient());
        myWebView = (WebView) findViewById(R.id.NoticiasView);
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
    }*/
}
package equipepoli.com.bajapoli.ui.forum;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ExpandableListView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import equipepoli.com.bajapoli.R;
import equipepoli.com.bajapoli.ui.forum.MainAdapter;

public class Forum extends AppCompatActivity {
    ExpandableListView expandableListView;
    List <String> listGroup;
    HashMap <String, List<String>> listItem;
    MainAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forum);

        expandableListView = findViewById(R.id.expandable_listview);
        listGroup = new ArrayList<>();
        listItem = new HashMap<>();
        adapter =  new MainAdapter(this, listGroup, listItem);
        expandableListView.setAdapter(adapter);
        initListData();
    }
    private void initListData(){
        listGroup.add(getString(R.string.grupo1));
        listGroup.add(getString(R.string.grupo2));
        listGroup.add(getString(R.string.grupo3));
        listGroup.add(getString(R.string.grupo4));
        listGroup.add(getString(R.string.grupo5));
        listGroup.add(getString(R.string.grupo6));

        String [] array;

        List <String> list1 = new ArrayList<>();
        array = getResources().getStringArray(R.array.grupo1);
        for (String item: array){
            list1.add (item);
        }

        List <String> list2 = new ArrayList<>();
        array = getResources().getStringArray(R.array.grupo2);
        for (String item: array){
            list2.add (item);
        }

        List <String> list3 = new ArrayList<>();
        array = getResources().getStringArray(R.array.grupo3);
        for (String item: array){
            list3.add (item);
        }

        List <String> list4 = new ArrayList<>();
        array = getResources().getStringArray(R.array.grupo4);
        for (String item: array){
            list4.add (item);
        }

        List <String> list5 = new ArrayList<>();
        array = getResources().getStringArray(R.array.grupo5);
        for (String item: array){
            list5.add (item);
        }

        List <String> list6 = new ArrayList<>();
        array = getResources().getStringArray(R.array.grupo6);
        for (String item: array){
            list6.add (item);
        }

        listItem.put(listGroup.get(0), list1);
        listItem.put(listGroup.get(1), list2);
        listItem.put(listGroup.get(2), list3);
        listItem.put(listGroup.get(3), list4);
        listItem.put(listGroup.get(4), list5);
        listItem.put(listGroup.get(5), list6);
        adapter.notifyDataSetChanged();
    }
}
